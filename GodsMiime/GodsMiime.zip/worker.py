from GodsMiime.spiders.GodsMiimeSpider import handler

handler()
