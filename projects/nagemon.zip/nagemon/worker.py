from nagemon.spiders.nagemon_spider import handler

handler()
