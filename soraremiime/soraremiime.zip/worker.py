from soraremiime.spiders.sorare_spider import handler

handler()
